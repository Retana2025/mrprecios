/* =====================================================================
   datos.js  -  "Base de datos" de MRS Precios
   ---------------------------------------------------------------------
   Este archivo funciona como una base de datos hecha con tablas:

     TIENDAS     -> una fila por tienda (5)
     CATEGORIAS  -> una fila por categoría (5)
     PRODUCTOS   -> una fila por producto (20 por categoría = 100)
     PRECIOS     -> una fila por (producto + tienda). Relaciona las
                    tablas anteriores usando llaves foráneas:
                       p = id del producto, t = id de la tienda
     COMBOS      -> ofertas que agrupan varios productos
     SITUACIONES -> atajos de la pantalla de inicio

   Todos los datos son de EJEMPLO: tiendas, marcas y precios ficticios.
   Se usan variables globales (const) para que funcione abriendo
   index.html con doble clic, sin servidor.
   ===================================================================== */

// Fecha de la última "lectura" de precios (se muestra en la página)
const FECHA_ACTUALIZACION = "2026-11-19";

/* ---------------------------------------------------------------------
   TABLA: TIENDAS
   id      -> identificador único (llave primaria)
   slug    -> texto para usar en direcciones (#/tienda/tecnocasa)
   color   -> color de la tarjeta/logo de la tienda
   tipo    -> a qué se dedica (sirve para filtrar)
   --------------------------------------------------------------------- */
const TIENDAS = [
  { id: 1, nombre: "TecnoCasa", slug: "tecnocasa", color: "#E4572E", tipo: "Tecnología y hogar" },
  { id: 2, nombre: "ElectroMax", slug: "electromax", color: "#17A398", tipo: "Electrónica y electrodomésticos" },
  { id: 3, nombre: "Casa Tica", slug: "casa-tica", color: "#8E44AD", tipo: "Hogar y ferretería" },
  { id: 4, nombre: "SuperHogar", slug: "superhogar", color: "#F2A900", tipo: "Supermercado y hogar" },
  { id: 6, nombre: "Todo Auto", slug: "todo-auto", color: "#D6336C", tipo: "Automotriz y herramientas" }
];

/* ---------------------------------------------------------------------
   TABLA: CATEGORIAS
   icono -> emoji temporal (más adelante podemos cambiarlo por SVG)
   --------------------------------------------------------------------- */
const CATEGORIAS = [
  { id: "linea-blanca", nombre: "Línea blanca", icono: "🧊" },
  { id: "electronicos", nombre: "Electrónicos", icono: "📺" },
  { id: "hogar", nombre: "Hogar", icono: "🏠" },
  { id: "ferreteria", nombre: "Ferretería y herramientas", icono: "🔧" },
  { id: "automotriz", nombre: "Automotriz", icono: "🚗" }
];

/* ---------------------------------------------------------------------
   TABLA: PRODUCTOS  (20 por categoría)
   categoria -> llave foránea que apunta a CATEGORIAS.id
   imagen    -> nombre de la foto del producto dentro de la carpeta img/
                (sin extensión: "refrigeradora-2" carga img/refrigeradora-2.jpg).
                Solo están los productos que tienen foto.
   emoji     -> respaldo por si la foto no carga
   --------------------------------------------------------------------- */
const PRODUCTOS = [
  { id: 1, nombre: "Refrigeradora Side by Side 20 pies", marca: "Nordik", categoria: "linea-blanca", imagen: "refrigeradora", emoji: "🧊", descripcion: "Dos puertas, dispensador de agua y control digital de temperatura." },
  { id: 2, nombre: "Lavadora automática 16 kg", marca: "Nordik", categoria: "linea-blanca", imagen: "lavadora", emoji: "🧺", descripcion: "Carga superior, 10 programas de lavado y ahorro de agua." },
  { id: 3, nombre: "Smart TV 55 pulgadas 4K UHD", marca: "Vizion", categoria: "electronicos", imagen: "tv55", emoji: "📺", descripcion: "Pantalla LED 4K con aplicaciones de streaming integradas." },
  { id: 4, nombre: "Consola de videojuegos Slim 1 TB", marca: "Gamerix", categoria: "electronicos", imagen: "consola", emoji: "🎮", descripcion: "Consola de nueva generación con 1 TB de almacenamiento y un control." },
  { id: 5, nombre: "Audífonos inalámbricos con cancelación de ruido", marca: "Sonora", categoria: "electronicos", imagen: "audifonos", emoji: "🎧", descripcion: "Bluetooth 5.3, hasta 30 horas de batería y micrófono integrado." },
  { id: 6, nombre: "Juego de sábanas queen 400 hilos", marca: "Dormir", categoria: "hogar", imagen: "sabanas", emoji: "🛏️", descripcion: "Algodón suave, incluye sábana ajustable, sábana plana y 2 fundas." },
  { id: 7, nombre: "Set de ollas antiadherentes 10 piezas", marca: "Chefix", categoria: "hogar", imagen: "ollas", emoji: "🍳", descripcion: "Aluminio con recubrimiento antiadherente, apto para cocina de gas y eléctrica." },
  { id: 8, nombre: "Taladro inalámbrico 20V con 2 baterías", marca: "Forja", categoria: "ferreteria", imagen: "taladro", emoji: "🔧", descripcion: "Mandril de 13 mm, 2 velocidades y luz LED." },
  { id: 9, nombre: "Caja de herramientas 120 piezas", marca: "Forja", categoria: "ferreteria", imagen: "caja-herramientas", emoji: "🧰", descripcion: "Llaves, dados, destornilladores y alicates en maletín resistente." },
  { id: 10, nombre: "Llanta 205/55 R16", marca: "Rodar", categoria: "automotriz", imagen: "llanta", emoji: "🛞", descripcion: "Llanta para sedán, buen agarre en lluvia y desgaste parejo." },
  { id: 11, nombre: "Batería para auto 12V 60Ah", marca: "Voltix", categoria: "automotriz", imagen: "bateria-auto", emoji: "🔋", descripcion: "Libre de mantenimiento, 18 meses de garantía." },
  { id: 26, nombre: "Refrigeradora Top Freezer 12 pies", marca: "Hielux", categoria: "linea-blanca", imagen: "refrigeradora-2", emoji: "🧊", descripcion: "Con control de temperatura y estantes ajustables." },
  { id: 27, nombre: "Refrigeradora Top Freezer 14 pies", marca: "Domus", categoria: "linea-blanca", imagen: "refrigeradora-3", emoji: "🧊", descripcion: "Con control de temperatura y estantes ajustables." },
  { id: 28, nombre: "Refrigeradora Bottom Freezer 18 pies", marca: "Polar Tica", categoria: "linea-blanca", imagen: "refrigeradora-4", emoji: "🧊", descripcion: "Con control de temperatura y estantes ajustables." },
  { id: 29, nombre: "Refrigeradora French Door 24 pies", marca: "Nordik", categoria: "linea-blanca", imagen: "refrigeradora-5", emoji: "🧊", descripcion: "Con control de temperatura y estantes ajustables." },
  { id: 30, nombre: "Lavadora automática 12 kg", marca: "Hielux", categoria: "linea-blanca", imagen: "lavadora-2", emoji: "🧺", descripcion: "Varios programas de lavado y ahorro de agua." },
  { id: 31, nombre: "Lavadora automática 14 kg", marca: "Domus", categoria: "linea-blanca", imagen: "lavadora-3", emoji: "🧺", descripcion: "Varios programas de lavado y ahorro de agua." },
  { id: 32, nombre: "Lavadora automática 18 kg", marca: "Polar Tica", categoria: "linea-blanca", imagen: "lavadora-4", emoji: "🧺", descripcion: "Varios programas de lavado y ahorro de agua." },
  { id: 33, nombre: "Lavadora de carga frontal 10 kg", marca: "Nordik", categoria: "linea-blanca", imagen: "lavadora-5", emoji: "🧺", descripcion: "Varios programas de lavado y ahorro de agua." },
  { id: 34, nombre: "Smart TV 32 pulgadas HD", marca: "Gamerix", categoria: "electronicos", imagen: "tv55-2", emoji: "📺", descripcion: "Pantalla LED con aplicaciones de streaming integradas." },
  { id: 35, nombre: "Smart TV 43 pulgadas Full HD", marca: "Sonora", categoria: "electronicos", imagen: "tv55-3", emoji: "📺", descripcion: "Pantalla LED con aplicaciones de streaming integradas." },
  { id: 36, nombre: "Smart TV 50 pulgadas 4K UHD", marca: "Pixelon", categoria: "electronicos", imagen: "tv55-4", emoji: "📺", descripcion: "Pantalla LED con aplicaciones de streaming integradas." },
  { id: 37, nombre: "Smart TV 65 pulgadas 4K UHD", marca: "Vizion", categoria: "electronicos", imagen: "tv55-5", emoji: "📺", descripcion: "Pantalla LED con aplicaciones de streaming integradas." },
  { id: 38, nombre: "Consola de videojuegos Slim 500 GB", marca: "Vizion", categoria: "electronicos", imagen: "consola-2", emoji: "🎮", descripcion: "Para jugar en casa, incluye control inalámbrico." },
  { id: 39, nombre: "Consola de videojuegos Pro 2 TB", marca: "Sonora", categoria: "electronicos", imagen: "consola-3", emoji: "🎮", descripcion: "Para jugar en casa, incluye control inalámbrico." },
  { id: 40, nombre: "Consola de videojuegos portátil 64 GB", marca: "Pixelon", categoria: "electronicos", imagen: "consola-4", emoji: "🎮", descripcion: "Para jugar en casa, incluye control inalámbrico." },
  { id: 41, nombre: "Consola de videojuegos portátil OLED 128 GB", marca: "Gamerix", categoria: "electronicos", imagen: "consola-5", emoji: "🎮", descripcion: "Para jugar en casa, incluye control inalámbrico." },
  { id: 42, nombre: "Audífonos con cable manos libres", marca: "Vizion", categoria: "electronicos", imagen: "audifonos-2", emoji: "🎧", descripcion: "Sonido claro para música, llamadas y videos." },
  { id: 43, nombre: "Audífonos inalámbricos deportivos", marca: "Gamerix", categoria: "electronicos", imagen: "audifonos-3", emoji: "🎧", descripcion: "Sonido claro para música, llamadas y videos." },
  { id: 44, nombre: "Audífonos inalámbricos tipo diadema", marca: "Pixelon", categoria: "electronicos", imagen: "audifonos-4", emoji: "🎧", descripcion: "Sonido claro para música, llamadas y videos." },
  { id: 45, nombre: "Audífonos inalámbricos premium con estuche de carga", marca: "Sonora", categoria: "electronicos", imagen: "audifonos-5", emoji: "🎧", descripcion: "Sonido claro para música, llamadas y videos." },
  { id: 46, nombre: "Juego de sábanas twin 300 hilos", marca: "Chefix", categoria: "hogar", imagen: "sabanas-2", emoji: "🛏️", descripcion: "Tela suave y fácil de lavar." },
  { id: 47, nombre: "Juego de sábanas full 300 hilos", marca: "Casaluz", categoria: "hogar", imagen: "sabanas-3", emoji: "🛏️", descripcion: "Tela suave y fácil de lavar." },
  { id: 48, nombre: "Juego de sábanas king 400 hilos", marca: "Hogarte", categoria: "hogar", imagen: "sabanas-4", emoji: "🛏️", descripcion: "Tela suave y fácil de lavar." },
  { id: 49, nombre: "Juego de sábanas king 600 hilos", marca: "Dormir", categoria: "hogar", imagen: "sabanas-5", emoji: "🛏️", descripcion: "Tela suave y fácil de lavar." },
  { id: 50, nombre: "Set de ollas antiadherentes 5 piezas", marca: "Dormir", categoria: "hogar", imagen: "ollas-2", emoji: "🍳", descripcion: "Aptas para cocina de gas y eléctrica." },
  { id: 51, nombre: "Set de ollas antiadherentes 7 piezas", marca: "Casaluz", categoria: "hogar", imagen: "ollas-3", emoji: "🍳", descripcion: "Aptas para cocina de gas y eléctrica." },
  { id: 52, nombre: "Set de ollas de acero inoxidable 12 piezas", marca: "Hogarte", categoria: "hogar", imagen: "ollas-4", emoji: "🍳", descripcion: "Aptas para cocina de gas y eléctrica." },
  { id: 53, nombre: "Set de ollas de hierro fundido 4 piezas", marca: "Chefix", categoria: "hogar", imagen: "ollas-5", emoji: "🍳", descripcion: "Aptas para cocina de gas y eléctrica." },
  { id: 54, nombre: "Taladro inalámbrico 12V", marca: "Torqueo", categoria: "ferreteria", imagen: "taladro-2", emoji: "🔧", descripcion: "Para trabajos de taladrado en casa y taller." },
  { id: 55, nombre: "Taladro percutor 710 W con cable", marca: "Ferrix", categoria: "ferreteria", imagen: "taladro-3", emoji: "🔧", descripcion: "Para trabajos de taladrado en casa y taller." },
  { id: 56, nombre: "Taladro inalámbrico 18V compacto", marca: "Forja", categoria: "ferreteria", imagen: "taladro-4", emoji: "🔧", descripcion: "Para trabajos de taladrado en casa y taller." },
  { id: 57, nombre: "Taladro rotomartillo inalámbrico 20V", marca: "Torqueo", categoria: "ferreteria", imagen: "taladro-5", emoji: "🔧", descripcion: "Para trabajos de taladrado en casa y taller." },
  { id: 58, nombre: "Caja de herramientas 40 piezas", marca: "Torqueo", categoria: "ferreteria", imagen: "caja-herramientas-2", emoji: "🧰", descripcion: "Herramientas básicas organizadas en maletín resistente." },
  { id: 59, nombre: "Caja de herramientas 80 piezas", marca: "Ferrix", categoria: "ferreteria", imagen: "caja-herramientas-3", emoji: "🧰", descripcion: "Herramientas básicas organizadas en maletín resistente." },
  { id: 60, nombre: "Caja de herramientas 200 piezas", marca: "Forja", categoria: "ferreteria", imagen: "caja-herramientas-4", emoji: "🧰", descripcion: "Herramientas básicas organizadas en maletín resistente." },
  { id: 61, nombre: "Caja de herramientas 250 piezas profesional", marca: "Torqueo", categoria: "ferreteria", imagen: "caja-herramientas-5", emoji: "🧰", descripcion: "Herramientas básicas organizadas en maletín resistente." },
  { id: 62, nombre: "Llanta 185/65 R14", marca: "Voltix", categoria: "automotriz", imagen: "llanta-2", emoji: "🛞", descripcion: "Buen agarre y desgaste parejo." },
  { id: 63, nombre: "Llanta 195/65 R15", marca: "Ruteo", categoria: "automotriz", imagen: "llanta-3", emoji: "🛞", descripcion: "Buen agarre y desgaste parejo." },
  { id: 64, nombre: "Llanta 225/45 R17", marca: "Pistón", categoria: "automotriz", imagen: "llanta-4", emoji: "🛞", descripcion: "Buen agarre y desgaste parejo." },
  { id: 65, nombre: "Llanta 265/65 R17 todo terreno", marca: "Rodar", categoria: "automotriz", imagen: "llanta-5", emoji: "🛞", descripcion: "Buen agarre y desgaste parejo." },
  { id: 66, nombre: "Batería para auto 12V 45Ah", marca: "Rodar", categoria: "automotriz", imagen: "bateria-auto-2", emoji: "🔋", descripcion: "Libre de mantenimiento con garantía incluida." },
  { id: 67, nombre: "Batería para auto 12V 55Ah", marca: "Ruteo", categoria: "automotriz", imagen: "bateria-auto-3", emoji: "🔋", descripcion: "Libre de mantenimiento con garantía incluida." },
  { id: 68, nombre: "Batería para auto 12V 70Ah", marca: "Pistón", categoria: "automotriz", imagen: "bateria-auto-4", emoji: "🔋", descripcion: "Libre de mantenimiento con garantía incluida." },
  { id: 69, nombre: "Batería para auto 12V 90Ah para pickup", marca: "Voltix", categoria: "automotriz", imagen: "bateria-auto-5", emoji: "🔋", descripcion: "Libre de mantenimiento con garantía incluida." },
  { id: 126, nombre: "Cocina a gas 4 quemadores 20 pulgadas", marca: "Hielux", categoria: "linea-blanca", imagen: "cocina-gas-1", emoji: "🔥", descripcion: "Con encendido eléctrico y parrillas resistentes." },
  { id: 127, nombre: "Cocina a gas 4 quemadores 30 pulgadas", marca: "Polar Tica", categoria: "linea-blanca", imagen: "cocina-gas-2", emoji: "🔥", descripcion: "Con encendido eléctrico y parrillas resistentes." },
  { id: 128, nombre: "Cocina a gas 5 quemadores 30 pulgadas con horno", marca: "Hielux", categoria: "linea-blanca", imagen: "cocina-gas-3", emoji: "🔥", descripcion: "Con encendido eléctrico y parrillas resistentes." },
  { id: 129, nombre: "Cocina a gas 6 quemadores 36 pulgadas", marca: "Polar Tica", categoria: "linea-blanca", imagen: "cocina-gas-4", emoji: "🔥", descripcion: "Con encendido eléctrico y parrillas resistentes." },
  { id: 130, nombre: "Cocina a gas 4 quemadores empotrable", marca: "Hielux", categoria: "linea-blanca", imagen: "cocina-gas-5", emoji: "🔥", descripcion: "Con encendido eléctrico y parrillas resistentes." },
  { id: 131, nombre: "Congelador horizontal 5 pies", marca: "Domus", categoria: "linea-blanca", imagen: "congelador-1", emoji: "🥶", descripcion: "Conserva carnes y alimentos por más tiempo." },
  { id: 132, nombre: "Congelador horizontal 7 pies", marca: "Nordik", categoria: "linea-blanca", imagen: "congelador-2", emoji: "🥶", descripcion: "Conserva carnes y alimentos por más tiempo." },
  { id: 133, nombre: "Congelador horizontal 9 pies", marca: "Domus", categoria: "linea-blanca", imagen: "congelador-3", emoji: "🥶", descripcion: "Conserva carnes y alimentos por más tiempo." },
  { id: 134, nombre: "Congelador horizontal 12 pies", marca: "Nordik", categoria: "linea-blanca", imagen: "congelador-4", emoji: "🥶", descripcion: "Conserva carnes y alimentos por más tiempo." },
  { id: 135, nombre: "Congelador horizontal 15 pies", marca: "Domus", categoria: "linea-blanca", imagen: "congelador-5", emoji: "🥶", descripcion: "Conserva carnes y alimentos por más tiempo." },
  { id: 136, nombre: "Parlante Bluetooth portátil 10 W", marca: "Pixelon", categoria: "electronicos", imagen: "parlante-1", emoji: "🔊", descripcion: "Sonido potente con conexión inalámbrica." },
  { id: 137, nombre: "Parlante Bluetooth portátil resistente al agua 20 W", marca: "Gamerix", categoria: "electronicos", imagen: "parlante-2", emoji: "🔊", descripcion: "Sonido potente con conexión inalámbrica." },
  { id: 138, nombre: "Parlante Bluetooth torre con luces 60 W", marca: "Pixelon", categoria: "electronicos", imagen: "parlante-3", emoji: "🔊", descripcion: "Sonido potente con conexión inalámbrica." },
  { id: 139, nombre: "Parlante Bluetooth barra de sonido 2.1", marca: "Gamerix", categoria: "electronicos", imagen: "parlante-4", emoji: "🔊", descripcion: "Sonido potente con conexión inalámbrica." },
  { id: 140, nombre: "Parlante Bluetooth barra de sonido 5.1 con subwoofer", marca: "Pixelon", categoria: "electronicos", imagen: "parlante-5", emoji: "🔊", descripcion: "Sonido potente con conexión inalámbrica." },
  { id: 141, nombre: "Juego de toallas 3 piezas algodón", marca: "Dormir", categoria: "hogar", imagen: "toallas-1", emoji: "🛁", descripcion: "Algodón absorbente y de secado rápido." },
  { id: 142, nombre: "Juego de toallas 4 piezas algodón", marca: "Casaluz", categoria: "hogar", imagen: "toallas-2", emoji: "🛁", descripcion: "Algodón absorbente y de secado rápido." },
  { id: 143, nombre: "Juego de toallas 6 piezas algodón", marca: "Dormir", categoria: "hogar", imagen: "toallas-3", emoji: "🛁", descripcion: "Algodón absorbente y de secado rápido." },
  { id: 144, nombre: "Juego de toallas 6 piezas premium", marca: "Casaluz", categoria: "hogar", imagen: "toallas-4", emoji: "🛁", descripcion: "Algodón absorbente y de secado rápido." },
  { id: 145, nombre: "Juego de toallas 8 piezas premium", marca: "Dormir", categoria: "hogar", imagen: "toallas-5", emoji: "🛁", descripcion: "Algodón absorbente y de secado rápido." },
  { id: 146, nombre: "Lámpara de mesa LED básica", marca: "Chefix", categoria: "hogar", imagen: "lampara-1", emoji: "💡", descripcion: "Luz cómoda para lectura, estudio o decoración." },
  { id: 147, nombre: "Lámpara de mesa LED regulable", marca: "Hogarte", categoria: "hogar", imagen: "lampara-2", emoji: "💡", descripcion: "Luz cómoda para lectura, estudio o decoración." },
  { id: 148, nombre: "Lámpara de mesa de lectura con base de madera", marca: "Chefix", categoria: "hogar", imagen: "lampara-3", emoji: "💡", descripcion: "Luz cómoda para lectura, estudio o decoración." },
  { id: 149, nombre: "Lámpara de mesa con cargador inalámbrico", marca: "Hogarte", categoria: "hogar", imagen: "lampara-4", emoji: "💡", descripcion: "Luz cómoda para lectura, estudio o decoración." },
  { id: 150, nombre: "Lámpara de mesa tipo escritorio articulada", marca: "Chefix", categoria: "hogar", imagen: "lampara-5", emoji: "💡", descripcion: "Luz cómoda para lectura, estudio o decoración." },
  { id: 151, nombre: "Escalera de aluminio 3 peldaños", marca: "Forja", categoria: "ferreteria", imagen: "escalera-1", emoji: "🪜", descripcion: "Estructura resistente y antideslizante." },
  { id: 152, nombre: "Escalera de aluminio 5 peldaños", marca: "Ferrix", categoria: "ferreteria", imagen: "escalera-2", emoji: "🪜", descripcion: "Estructura resistente y antideslizante." },
  { id: 153, nombre: "Escalera de aluminio tijera 6 peldaños", marca: "Torqueo", categoria: "ferreteria", imagen: "escalera-3", emoji: "🪜", descripcion: "Estructura resistente y antideslizante." },
  { id: 154, nombre: "Escalera de aluminio telescópica 3.8 m", marca: "Forja", categoria: "ferreteria", imagen: "escalera-4", emoji: "🪜", descripcion: "Estructura resistente y antideslizante." },
  { id: 155, nombre: "Escalera de aluminio multiposición 4x3", marca: "Ferrix", categoria: "ferreteria", imagen: "escalera-5", emoji: "🪜", descripcion: "Estructura resistente y antideslizante." },
  { id: 156, nombre: "Esmeriladora angular de 4 1/2 pulgadas 750 W", marca: "Ferrix", categoria: "ferreteria", imagen: "esmeriladora-1", emoji: "⚙️", descripcion: "Para cortar y desbastar metal y mampostería." },
  { id: 157, nombre: "Esmeriladora angular de 4 1/2 pulgadas 900 W", marca: "Torqueo", categoria: "ferreteria", imagen: "esmeriladora-2", emoji: "⚙️", descripcion: "Para cortar y desbastar metal y mampostería." },
  { id: 158, nombre: "Esmeriladora angular de 5 pulgadas 1100 W", marca: "Forja", categoria: "ferreteria", imagen: "esmeriladora-3", emoji: "⚙️", descripcion: "Para cortar y desbastar metal y mampostería." },
  { id: 159, nombre: "Esmeriladora angular de 7 pulgadas 2200 W", marca: "Ferrix", categoria: "ferreteria", imagen: "esmeriladora-4", emoji: "⚙️", descripcion: "Para cortar y desbastar metal y mampostería." },
  { id: 160, nombre: "Esmeriladora angular inalámbrica 20V", marca: "Torqueo", categoria: "ferreteria", imagen: "esmeriladora-5", emoji: "⚙️", descripcion: "Para cortar y desbastar metal y mampostería." },
  { id: 161, nombre: "Aceite de motor 5W-30 sintético 1 galón", marca: "Rodar", categoria: "automotriz", imagen: "aceite-motor-1", emoji: "🛢️", descripcion: "Protege el motor y reduce el desgaste." },
  { id: 162, nombre: "Aceite de motor 5W-30 sintético 4 litros", marca: "Ruteo", categoria: "automotriz", imagen: "aceite-motor-2", emoji: "🛢️", descripcion: "Protege el motor y reduce el desgaste." },
  { id: 163, nombre: "Aceite de motor 10W-40 semisintético 1 galón", marca: "Rodar", categoria: "automotriz", imagen: "aceite-motor-3", emoji: "🛢️", descripcion: "Protege el motor y reduce el desgaste." },
  { id: 164, nombre: "Aceite de motor 20W-50 mineral 1 galón", marca: "Ruteo", categoria: "automotriz", imagen: "aceite-motor-4", emoji: "🛢️", descripcion: "Protege el motor y reduce el desgaste." },
  { id: 165, nombre: "Aceite de motor 0W-20 sintético 5 litros", marca: "Rodar", categoria: "automotriz", imagen: "aceite-motor-5", emoji: "🛢️", descripcion: "Protege el motor y reduce el desgaste." },
  { id: 166, nombre: "Cables pasacorriente de 2 metros", marca: "Voltix", categoria: "automotriz", imagen: "cables-pasacorriente-1", emoji: "🔌", descripcion: "Para arrancar el vehículo con la batería descargada." },
  { id: 167, nombre: "Cables pasacorriente de 3 metros calibre 8", marca: "Pistón", categoria: "automotriz", imagen: "cables-pasacorriente-2", emoji: "🔌", descripcion: "Para arrancar el vehículo con la batería descargada." },
  { id: 168, nombre: "Cables pasacorriente de 4 metros calibre 6", marca: "Voltix", categoria: "automotriz", imagen: "cables-pasacorriente-3", emoji: "🔌", descripcion: "Para arrancar el vehículo con la batería descargada." },
  { id: 169, nombre: "Cables pasacorriente de 5 metros uso pesado", marca: "Pistón", categoria: "automotriz", imagen: "cables-pasacorriente-4", emoji: "🔌", descripcion: "Para arrancar el vehículo con la batería descargada." },
  { id: 170, nombre: "Cables pasacorriente de 6 metros calibre 4 profesional", marca: "Voltix", categoria: "automotriz", imagen: "cables-pasacorriente-5", emoji: "🔌", descripcion: "Para arrancar el vehículo con la batería descargada." }
];

/* ---------------------------------------------------------------------
   TABLA: PRECIOS  (la que conecta productos con tiendas)
   p       -> id del producto   (llave foránea a PRODUCTOS.id)
   t       -> id de la tienda   (llave foránea a TIENDAS.id)
   precio  -> precio actual en colones (₡)
   hist    -> precios de hace 30, 20 y 10 días (para el historial)
   Cada producto aparece en 2 o más tiendas.
   --------------------------------------------------------------------- */
const PRECIOS = [
  // 1 Refrigeradora Side by Side 20 pies
  { p: 1, t: 1, precio: 459900, hist: [489900, 479900, 469900] },
  { p: 1, t: 2, precio: 449900, hist: [469900, 459900, 455900] },
  { p: 1, t: 4, precio: 479000, hist: [479000, 479000, 485000] },
  // 2 Lavadora automática 16 kg
  { p: 2, t: 1, precio: 299000, hist: [299000, 305000, 299000] },
  { p: 2, t: 2, precio: 289900, hist: [309900, 299900, 294900] },
  { p: 2, t: 4, precio: 279500, hist: [289900, 289900, 284900] },
  // 3 Smart TV 55 pulgadas 4K UHD
  { p: 3, t: 1, precio: 232900, hist: [259900, 249900, 239900] },
  { p: 3, t: 2, precio: 224900, hist: [239900, 234900, 229900] },
  { p: 3, t: 3, precio: 239000, hist: [239000, 245000, 239000] },
  // 4 Consola de videojuegos Slim 1 TB
  { p: 4, t: 1, precio: 389000, hist: [409000, 399000, 395000] },
  { p: 4, t: 2, precio: 395000, hist: [405000, 399000, 399000] },
  // 5 Audífonos inalámbricos con cancelación de ruido
  { p: 5, t: 1, precio: 59900, hist: [74900, 69900, 64900] },
  { p: 5, t: 2, precio: 54900, hist: [64900, 59900, 57900] },
  { p: 5, t: 3, precio: 62500, hist: [62500, 62500, 64900] },
  // 6 Juego de sábanas queen 400 hilos
  { p: 6, t: 3, precio: 24900, hist: [29900, 27900, 26900] },
  { p: 6, t: 4, precio: 22500, hist: [26500, 24900, 23900] },
  // 7 Set de ollas antiadherentes 10 piezas
  { p: 7, t: 2, precio: 41000, hist: [41000, 42500, 41000] },
  { p: 7, t: 3, precio: 38900, hist: [44900, 42900, 40900] },
  { p: 7, t: 4, precio: 36500, hist: [41900, 39900, 38000] },
  // 8 Taladro inalámbrico 20V con 2 baterías
  { p: 8, t: 1, precio: 49900, hist: [54900, 52900, 51500] },
  { p: 8, t: 3, precio: 45500, hist: [49900, 47900, 46500] },
  // 9 Caja de herramientas 120 piezas
  { p: 9, t: 3, precio: 28900, hist: [32900, 31500, 29900] },
  { p: 9, t: 4, precio: 31500, hist: [31500, 33900, 31500] },
  // 10 Llanta 205/55 R16
  { p: 10, t: 3, precio: 62900, hist: [67900, 65900, 64500] },
  { p: 10, t: 4, precio: 59500, hist: [64900, 62900, 60900] },
  // 11 Batería para auto 12V 60Ah
  { p: 11, t: 3, precio: 78500, hist: [84900, 82500, 79900] },
  { p: 11, t: 4, precio: 81900, hist: [81900, 81900, 84900] },
  // 26 Refrigeradora Top Freezer 12 pies
  { p: 26, t: 1, precio: 230700, hist: [230700, 239400, 230700] },
  { p: 26, t: 2, precio: 254300, hist: [265100, 258100, 256500] },
  // 27 Refrigeradora Top Freezer 14 pies
  { p: 27, t: 1, precio: 273500, hist: [311200, 305800, 287200] },
  { p: 27, t: 2, precio: 284700, hist: [319900, 308100, 294000] },
  { p: 27, t: 3, precio: 303800, hist: [303800, 313600, 303800] },
  // 28 Refrigeradora Bottom Freezer 18 pies
  { p: 28, t: 1, precio: 436900, hist: [423800, 430500, 431000] },
  { p: 28, t: 2, precio: 434500, hist: [450100, 447300, 437300] },
  // 29 Refrigeradora French Door 24 pies
  { p: 29, t: 1, precio: 707500, hist: [757500, 736800, 722000] },
  { p: 29, t: 3, precio: 622400, hist: [622400, 630400, 622400] },
  // 30 Lavadora automática 12 kg
  { p: 30, t: 1, precio: 225800, hist: [255000, 248300, 242100] },
  { p: 30, t: 2, precio: 243400, hist: [275600, 254200, 249900] },
  { p: 30, t: 3, precio: 232100, hist: [248400, 238800, 235600] },
  { p: 30, t: 4, precio: 240700, hist: [240700, 243500, 240700] },
  // 31 Lavadora automática 14 kg
  { p: 31, t: 1, precio: 259700, hist: [294300, 273700, 271900] },
  { p: 31, t: 2, precio: 278300, hist: [309100, 301300, 300600] },
  { p: 31, t: 3, precio: 255200, hist: [255200, 255200, 255200] },
  // 32 Lavadora automática 18 kg
  { p: 32, t: 2, precio: 336900, hist: [336900, 340700, 336900] },
  { p: 32, t: 3, precio: 358200, hist: [358200, 359400, 358200] },
  { p: 32, t: 4, precio: 366900, hist: [405000, 378200, 375500] },
  // 33 Lavadora de carga frontal 10 kg
  { p: 33, t: 2, precio: 326300, hist: [358900, 356300, 343300] },
  { p: 33, t: 3, precio: 311700, hist: [348200, 317300, 316400] },
  // 34 Smart TV 32 pulgadas HD
  { p: 34, t: 1, precio: 87400, hist: [98800, 98500, 93300] },
  { p: 34, t: 2, precio: 89000, hist: [101000, 95700, 93700] },
  { p: 34, t: 3, precio: 95600, hist: [95600, 95700, 95600] },
  // 35 Smart TV 43 pulgadas Full HD
  { p: 35, t: 1, precio: 146500, hist: [158900, 153200, 151000] },
  { p: 35, t: 2, precio: 146600, hist: [140400, 141200, 145800] },
  { p: 35, t: 3, precio: 140100, hist: [140100, 142200, 140100] },
  // 36 Smart TV 50 pulgadas 4K UHD
  { p: 36, t: 1, precio: 190300, hist: [190300, 192800, 190300] },
  { p: 36, t: 2, precio: 197100, hist: [197100, 199500, 197100] },
  { p: 36, t: 3, precio: 198200, hist: [193800, 194000, 194600] },
  // 37 Smart TV 65 pulgadas 4K UHD
  { p: 37, t: 1, precio: 335100, hist: [369400, 366000, 348700] },
  { p: 37, t: 2, precio: 347600, hist: [392800, 361200, 360500] },
  { p: 37, t: 3, precio: 342500, hist: [342500, 352500, 342500] },
  // 38 Consola de videojuegos Slim 500 GB
  { p: 38, t: 1, precio: 319600, hist: [330600, 327800, 323900] },
  { p: 38, t: 3, precio: 345500, hist: [363700, 361500, 359000] },
  // 39 Consola de videojuegos Pro 2 TB
  { p: 39, t: 1, precio: 532500, hist: [549400, 547100, 539800] },
  { p: 39, t: 2, precio: 471100, hist: [471100, 480700, 471100] },
  { p: 39, t: 3, precio: 516200, hist: [538800, 534600, 526700] },
  // 40 Consola de videojuegos portátil 64 GB
  { p: 40, t: 1, precio: 295800, hist: [311200, 303300, 301800] },
  { p: 40, t: 2, precio: 276700, hist: [289700, 284700, 281900] },
  { p: 40, t: 3, precio: 288900, hist: [324700, 312900, 295800] },
  // 41 Consola de videojuegos portátil OLED 128 GB
  { p: 41, t: 1, precio: 331800, hist: [367700, 345400, 343100] },
  { p: 41, t: 2, precio: 377300, hist: [399600, 390700, 386900] },
  { p: 41, t: 3, precio: 373700, hist: [373700, 376600, 373700] },
  // 42 Audífonos con cable manos libres
  { p: 42, t: 1, precio: 8100, hist: [9200, 8200, 8200] },
  { p: 42, t: 2, precio: 8200, hist: [9100, 8900, 8800] },
  { p: 42, t: 3, precio: 8100, hist: [8100, 8300, 8100] },
  // 43 Audífonos inalámbricos deportivos
  { p: 43, t: 1, precio: 31800, hist: [31800, 32300, 31800] },
  { p: 43, t: 2, precio: 29100, hist: [27700, 27700, 28000] },
  { p: 43, t: 3, precio: 30100, hist: [34100, 34000, 32100] },
  // 44 Audífonos inalámbricos tipo diadema
  { p: 44, t: 1, precio: 43800, hist: [46000, 46000, 44600] },
  { p: 44, t: 2, precio: 43400, hist: [48700, 45900, 44100] },
  // 45 Audífonos inalámbricos premium con estuche de carga
  { p: 45, t: 1, precio: 94100, hist: [101000, 100000, 98600] },
  { p: 45, t: 2, precio: 89100, hist: [99200, 97300, 93800] },
  { p: 45, t: 3, precio: 90900, hist: [90900, 93100, 90900] },
  // 46 Juego de sábanas twin 300 hilos
  { p: 46, t: 2, precio: 14400, hist: [14400, 14900, 14400] },
  { p: 46, t: 3, precio: 14200, hist: [15000, 14800, 14600] },
  // 47 Juego de sábanas full 300 hilos
  { p: 47, t: 2, precio: 18000, hist: [18000, 18700, 18000] },
  { p: 47, t: 3, precio: 19100, hist: [20500, 20300, 19800] },
  { p: 47, t: 4, precio: 18300, hist: [20600, 20200, 19600] },
  // 48 Juego de sábanas king 400 hilos
  { p: 48, t: 2, precio: 28700, hist: [32400, 31800, 29700] },
  { p: 48, t: 3, precio: 30000, hist: [32300, 31000, 31000] },
  { p: 48, t: 4, precio: 32500, hist: [35600, 34300, 33800] },
  // 49 Juego de sábanas king 600 hilos
  { p: 49, t: 2, precio: 44900, hist: [46400, 45700, 45200] },
  { p: 49, t: 3, precio: 47700, hist: [47700, 49000, 47700] },
  // 50 Set de ollas antiadherentes 5 piezas
  { p: 50, t: 2, precio: 23100, hist: [26100, 25600, 25500] },
  { p: 50, t: 3, precio: 23600, hist: [24400, 24200, 24200] },
  { p: 50, t: 4, precio: 21700, hist: [23400, 23400, 22400] },
  // 51 Set de ollas antiadherentes 7 piezas
  { p: 51, t: 2, precio: 30300, hist: [30300, 30500, 30300] },
  { p: 51, t: 3, precio: 31100, hist: [34500, 33000, 32000] },
  { p: 51, t: 4, precio: 30300, hist: [30300, 31200, 30300] },
  // 52 Set de ollas de acero inoxidable 12 piezas
  { p: 52, t: 2, precio: 63300, hist: [70800, 66700, 64700] },
  { p: 52, t: 3, precio: 68700, hist: [68700, 70800, 68700] },
  { p: 52, t: 4, precio: 64100, hist: [71600, 70700, 67300] },
  // 53 Set de ollas de hierro fundido 4 piezas
  { p: 53, t: 2, precio: 47900, hist: [54500, 51500, 48900] },
  { p: 53, t: 3, precio: 49400, hist: [51800, 51600, 50400] },
  { p: 53, t: 4, precio: 53900, hist: [56700, 56000, 55300] },
  // 54 Taladro inalámbrico 12V
  { p: 54, t: 1, precio: 29900, hist: [28100, 28900, 29400] },
  { p: 54, t: 6, precio: 32000, hist: [35800, 33500, 33300] },
  // 55 Taladro percutor 710 W con cable
  { p: 55, t: 1, precio: 40600, hist: [41900, 41200, 41200] },
  { p: 55, t: 3, precio: 39700, hist: [37200, 38900, 38900] },
  { p: 55, t: 6, precio: 41200, hist: [44500, 43400, 42800] },
  // 56 Taladro inalámbrico 18V compacto
  { p: 56, t: 1, precio: 43800, hist: [47200, 46000, 44100] },
  { p: 56, t: 3, precio: 40500, hist: [42100, 41500, 40800] },
  { p: 56, t: 6, precio: 44800, hist: [44800, 46200, 44800] },
  // 57 Taladro rotomartillo inalámbrico 20V
  { p: 57, t: 1, precio: 97500, hist: [103800, 100700, 99800] },
  { p: 57, t: 3, precio: 95800, hist: [106900, 103800, 100400] },
  { p: 57, t: 6, precio: 94100, hist: [94100, 94600, 94100] },
  // 58 Caja de herramientas 40 piezas
  { p: 58, t: 1, precio: 14000, hist: [15400, 14400, 14100] },
  { p: 58, t: 3, precio: 12700, hist: [13500, 13400, 12800] },
  { p: 58, t: 6, precio: 14000, hist: [14700, 14400, 14200] },
  // 59 Caja de herramientas 80 piezas
  { p: 59, t: 1, precio: 21100, hist: [21100, 21800, 21100] },
  { p: 59, t: 3, precio: 21200, hist: [22500, 22300, 21600] },
  { p: 59, t: 6, precio: 20700, hist: [20700, 21100, 20700] },
  // 60 Caja de herramientas 200 piezas
  { p: 60, t: 1, precio: 54000, hist: [60100, 55900, 54500] },
  { p: 60, t: 3, precio: 54100, hist: [61600, 55300, 54700] },
  { p: 60, t: 6, precio: 49200, hist: [52800, 50700, 49700] },
  // 61 Caja de herramientas 250 piezas profesional
  { p: 61, t: 1, precio: 72300, hist: [78000, 74600, 73400] },
  { p: 61, t: 3, precio: 78400, hist: [81400, 80100, 79900] },
  { p: 61, t: 6, precio: 71600, hist: [81100, 77200, 75500] },
  // 62 Llanta 185/65 R14
  { p: 62, t: 3, precio: 43100, hist: [44900, 44500, 43400] },
  { p: 62, t: 6, precio: 45900, hist: [45900, 46800, 45900] },
  // 63 Llanta 195/65 R15
  { p: 63, t: 3, precio: 56500, hist: [62200, 61300, 60500] },
  { p: 63, t: 4, precio: 49400, hist: [54300, 53900, 52800] },
  { p: 63, t: 6, precio: 50800, hist: [54500, 51800, 51100] },
  // 64 Llanta 225/45 R17
  { p: 64, t: 3, precio: 81800, hist: [79600, 80900, 81100] },
  { p: 64, t: 4, precio: 77500, hist: [83600, 82100, 81300] },
  { p: 64, t: 6, precio: 85700, hist: [80200, 83400, 85200] },
  // 65 Llanta 265/65 R17 todo terreno
  { p: 65, t: 3, precio: 125200, hist: [137400, 129700, 128900] },
  { p: 65, t: 6, precio: 128700, hist: [141800, 138200, 136800] },
  // 66 Batería para auto 12V 45Ah
  { p: 66, t: 3, precio: 63000, hist: [63000, 65000, 63000] },
  { p: 66, t: 4, precio: 59700, hist: [56000, 57900, 59000] },
  { p: 66, t: 6, precio: 59900, hist: [66100, 62600, 60400] },
  // 67 Batería para auto 12V 55Ah
  { p: 67, t: 3, precio: 73900, hist: [79900, 76100, 75100] },
  { p: 67, t: 4, precio: 67800, hist: [76500, 70800, 69400] },
  { p: 67, t: 6, precio: 75400, hist: [79500, 78700, 78400] },
  // 68 Batería para auto 12V 70Ah
  { p: 68, t: 3, precio: 99000, hist: [107800, 101600, 100500] },
  { p: 68, t: 4, precio: 95300, hist: [99600, 97800, 96400] },
  { p: 68, t: 6, precio: 97500, hist: [110900, 104400, 104200] },
  // 69 Batería para auto 12V 90Ah para pickup
  { p: 69, t: 3, precio: 127700, hist: [145200, 140700, 140600] },
  { p: 69, t: 4, precio: 118400, hist: [123700, 120400, 119900] },
  { p: 69, t: 6, precio: 131500, hist: [149500, 142300, 135300] },
  // 126 Cocina a gas 4 quemadores 20 pulgadas
  { p: 126, t: 1, precio: 138400, hist: [155500, 144700, 141500] },
  { p: 126, t: 3, precio: 137800, hist: [137800, 141100, 137800] },
  { p: 126, t: 4, precio: 126300, hist: [139500, 130200, 128900] },
  // 127 Cocina a gas 4 quemadores 30 pulgadas
  { p: 127, t: 1, precio: 185900, hist: [210900, 196300, 192700] },
  { p: 127, t: 2, precio: 181400, hist: [172000, 175400, 176700] },
  { p: 127, t: 4, precio: 195300, hist: [195300, 201300, 195300] },
  // 128 Cocina a gas 5 quemadores 30 pulgadas con horno
  { p: 128, t: 1, precio: 285900, hist: [276300, 278600, 282000] },
  { p: 128, t: 2, precio: 284400, hist: [274000, 278800, 279800] },
  { p: 128, t: 3, precio: 277300, hist: [302900, 291400, 285300] },
  // 129 Cocina a gas 6 quemadores 36 pulgadas
  { p: 129, t: 1, precio: 422600, hist: [459700, 459000, 458500] },
  { p: 129, t: 3, precio: 463700, hist: [463700, 471100, 463700] },
  { p: 129, t: 4, precio: 455800, hist: [494100, 476400, 458200] },
  // 130 Cocina a gas 4 quemadores empotrable
  { p: 130, t: 1, precio: 155300, hist: [175400, 165300, 161500] },
  { p: 130, t: 2, precio: 168200, hist: [178700, 176000, 173100] },
  { p: 130, t: 4, precio: 156000, hist: [167800, 162200, 159200] },
  // 131 Congelador horizontal 5 pies
  { p: 131, t: 1, precio: 189100, hist: [203000, 195200, 193100] },
  { p: 131, t: 2, precio: 195200, hist: [195200, 199000, 195200] },
  { p: 131, t: 3, precio: 198400, hist: [222100, 207100, 200300] },
  { p: 131, t: 4, precio: 193800, hist: [187300, 191000, 191800] },
  // 132 Congelador horizontal 7 pies
  { p: 132, t: 1, precio: 227400, hist: [238000, 233400, 229300] },
  { p: 132, t: 3, precio: 239900, hist: [239900, 247500, 239900] },
  { p: 132, t: 4, precio: 218700, hist: [214100, 216100, 216600] },
  // 133 Congelador horizontal 9 pies
  { p: 133, t: 1, precio: 289500, hist: [301200, 301200, 296900] },
  { p: 133, t: 2, precio: 285200, hist: [285200, 286200, 285200] },
  { p: 133, t: 3, precio: 277800, hist: [303700, 288700, 288700] },
  { p: 133, t: 4, precio: 292300, hist: [292300, 296600, 292300] },
  // 134 Congelador horizontal 12 pies
  { p: 134, t: 1, precio: 333300, hist: [333300, 334700, 333300] },
  { p: 134, t: 2, precio: 355500, hist: [355500, 362100, 355500] },
  { p: 134, t: 3, precio: 329300, hist: [355800, 354900, 334500] },
  // 135 Congelador horizontal 15 pies
  { p: 135, t: 1, precio: 406900, hist: [406900, 412700, 406900] },
  { p: 135, t: 3, precio: 429900, hist: [449000, 444600, 434100] },
  { p: 135, t: 4, precio: 398600, hist: [450000, 424200, 409900] },
  // 136 Parlante Bluetooth portátil 10 W
  { p: 136, t: 1, precio: 19000, hist: [19700, 19300, 19200] },
  { p: 136, t: 3, precio: 19900, hist: [21600, 20500, 20200] },
  // 137 Parlante Bluetooth portátil resistente al agua 20 W
  { p: 137, t: 1, precio: 35600, hist: [37300, 36600, 36400] },
  { p: 137, t: 2, precio: 35100, hist: [35100, 35800, 35100] },
  { p: 137, t: 3, precio: 36100, hist: [39700, 38200, 37100] },
  // 138 Parlante Bluetooth torre con luces 60 W
  { p: 138, t: 1, precio: 83300, hist: [78700, 79400, 79500] },
  { p: 138, t: 2, precio: 82400, hist: [91900, 87200, 86500] },
  // 139 Parlante Bluetooth barra de sonido 2.1
  { p: 139, t: 1, precio: 94800, hist: [94800, 97700, 94800] },
  { p: 139, t: 2, precio: 97900, hist: [106300, 103900, 101600] },
  { p: 139, t: 3, precio: 102600, hist: [109900, 104800, 103200] },
  // 140 Parlante Bluetooth barra de sonido 5.1 con subwoofer
  { p: 140, t: 2, precio: 162600, hist: [167500, 166200, 164900] },
  { p: 140, t: 3, precio: 180000, hist: [185900, 183700, 181200] },
  // 141 Juego de toallas 3 piezas algodón
  { p: 141, t: 2, precio: 11400, hist: [11400, 11400, 11400] },
  { p: 141, t: 3, precio: 11300, hist: [10900, 11000, 11000] },
  { p: 141, t: 4, precio: 11800, hist: [12200, 12000, 11900] },
  // 142 Juego de toallas 4 piezas algodón
  { p: 142, t: 2, precio: 17100, hist: [18900, 18700, 18100] },
  { p: 142, t: 3, precio: 15500, hist: [16500, 15800, 15700] },
  { p: 142, t: 4, precio: 16700, hist: [18300, 17600, 16900] },
  // 143 Juego de toallas 6 piezas algodón
  { p: 143, t: 2, precio: 22500, hist: [23700, 22900, 22700] },
  { p: 143, t: 3, precio: 23000, hist: [25100, 23900, 23500] },
  { p: 143, t: 4, precio: 24100, hist: [25800, 24600, 24400] },
  // 144 Juego de toallas 6 piezas premium
  { p: 144, t: 2, precio: 35200, hist: [35200, 35800, 35200] },
  { p: 144, t: 3, precio: 38000, hist: [41200, 41000, 39600] },
  { p: 144, t: 4, precio: 34300, hist: [36300, 35300, 34900] },
  // 145 Juego de toallas 8 piezas premium
  { p: 145, t: 2, precio: 43100, hist: [48200, 44600, 44000] },
  { p: 145, t: 3, precio: 46600, hist: [46600, 47100, 46600] },
  { p: 145, t: 4, precio: 43000, hist: [46600, 46100, 44100] },
  // 146 Lámpara de mesa LED básica
  { p: 146, t: 2, precio: 8400, hist: [9200, 9200, 9000] },
  { p: 146, t: 3, precio: 8900, hist: [9500, 9500, 9200] },
  { p: 146, t: 4, precio: 9200, hist: [9700, 9600, 9500] },
  // 147 Lámpara de mesa LED regulable
  { p: 147, t: 2, precio: 14700, hist: [13800, 14100, 14600] },
  { p: 147, t: 3, precio: 14300, hist: [15400, 14800, 14600] },
  { p: 147, t: 4, precio: 14800, hist: [16100, 16000, 15900] },
  // 148 Lámpara de mesa de lectura con base de madera
  { p: 148, t: 2, precio: 20900, hist: [22100, 21600, 21400] },
  { p: 148, t: 3, precio: 20100, hist: [21700, 21600, 21300] },
  { p: 148, t: 4, precio: 19200, hist: [21800, 20500, 20200] },
  // 149 Lámpara de mesa con cargador inalámbrico
  { p: 149, t: 2, precio: 26900, hist: [29800, 27900, 27400] },
  { p: 149, t: 3, precio: 27800, hist: [27800, 28400, 27800] },
  { p: 149, t: 4, precio: 27300, hist: [30400, 27900, 27800] },
  // 150 Lámpara de mesa tipo escritorio articulada
  { p: 150, t: 2, precio: 22500, hist: [24400, 23200, 22700] },
  { p: 150, t: 3, precio: 23600, hist: [24400, 24300, 23900] },
  { p: 150, t: 4, precio: 23700, hist: [23700, 24200, 23700] },
  // 151 Escalera de aluminio 3 peldaños
  { p: 151, t: 1, precio: 24800, hist: [27500, 26900, 26900] },
  { p: 151, t: 3, precio: 26900, hist: [28800, 28400, 28300] },
  { p: 151, t: 6, precio: 26100, hist: [29200, 27200, 26900] },
  // 152 Escalera de aluminio 5 peldaños
  { p: 152, t: 1, precio: 38900, hist: [38900, 39600, 38900] },
  { p: 152, t: 6, precio: 37200, hist: [42000, 38100, 38000] },
  // 153 Escalera de aluminio tijera 6 peldaños
  { p: 153, t: 1, precio: 53600, hist: [53600, 54100, 53600] },
  { p: 153, t: 6, precio: 59000, hist: [59000, 61200, 59000] },
  // 154 Escalera de aluminio telescópica 3.8 m
  { p: 154, t: 1, precio: 76500, hist: [76500, 76900, 76500] },
  { p: 154, t: 3, precio: 81900, hist: [77000, 79400, 80000] },
  { p: 154, t: 6, precio: 83500, hist: [90500, 89600, 88400] },
  // 155 Escalera de aluminio multiposición 4x3
  { p: 155, t: 1, precio: 99400, hist: [110300, 101900, 101600] },
  { p: 155, t: 3, precio: 101800, hist: [114700, 114400, 106200] },
  { p: 155, t: 6, precio: 105600, hist: [102400, 103400, 104500] },
  // 156 Esmeriladora angular de 4 1/2 pulgadas 750 W
  { p: 156, t: 1, precio: 34700, hist: [37900, 36400, 36300] },
  { p: 156, t: 3, precio: 31600, hist: [31600, 31800, 31600] },
  { p: 156, t: 6, precio: 31000, hist: [29400, 30300, 30700] },
  // 157 Esmeriladora angular de 4 1/2 pulgadas 900 W
  { p: 157, t: 1, precio: 37600, hist: [36300, 36400, 37400] },
  { p: 157, t: 6, precio: 39400, hist: [42800, 41400, 40900] },
  // 158 Esmeriladora angular de 5 pulgadas 1100 W
  { p: 158, t: 1, precio: 50100, hist: [52800, 51000, 50400] },
  { p: 158, t: 6, precio: 52000, hist: [58100, 57600, 56400] },
  // 159 Esmeriladora angular de 7 pulgadas 2200 W
  { p: 159, t: 1, precio: 85700, hist: [88800, 87000, 86800] },
  { p: 159, t: 3, precio: 76500, hist: [76500, 77800, 76500] },
  { p: 159, t: 6, precio: 82400, hist: [85400, 85300, 85000] },
  // 160 Esmeriladora angular inalámbrica 20V
  { p: 160, t: 1, precio: 70500, hist: [74200, 74000, 73000] },
  { p: 160, t: 3, precio: 74600, hist: [77100, 76800, 75900] },
  { p: 160, t: 6, precio: 75900, hist: [83700, 82300, 80200] },
  // 161 Aceite de motor 5W-30 sintético 1 galón
  { p: 161, t: 4, precio: 28600, hist: [31200, 29400, 29200] },
  { p: 161, t: 6, precio: 29900, hist: [29900, 30300, 29900] },
  // 162 Aceite de motor 5W-30 sintético 4 litros
  { p: 162, t: 3, precio: 33200, hist: [34800, 34000, 33700] },
  { p: 162, t: 6, precio: 34700, hist: [38300, 35500, 35000] },
  // 163 Aceite de motor 10W-40 semisintético 1 galón
  { p: 163, t: 3, precio: 19300, hist: [21800, 20200, 20100] },
  { p: 163, t: 4, precio: 21200, hist: [22700, 21600, 21300] },
  { p: 163, t: 6, precio: 20800, hist: [22400, 22400, 21900] },
  // 164 Aceite de motor 20W-50 mineral 1 galón
  { p: 164, t: 3, precio: 15000, hist: [15800, 15600, 15500] },
  { p: 164, t: 4, precio: 14600, hist: [14600, 14800, 14600] },
  { p: 164, t: 6, precio: 15300, hist: [17200, 16000, 15900] },
  // 165 Aceite de motor 0W-20 sintético 5 litros
  { p: 165, t: 4, precio: 42500, hist: [47200, 44300, 44200] },
  { p: 165, t: 6, precio: 48800, hist: [45500, 46200, 48000] },
  // 166 Cables pasacorriente de 2 metros
  { p: 166, t: 3, precio: 8500, hist: [9200, 9000, 8700] },
  { p: 166, t: 4, precio: 7700, hist: [7400, 7500, 7600] },
  { p: 166, t: 6, precio: 8100, hist: [9100, 8800, 8200] },
  // 167 Cables pasacorriente de 3 metros calibre 8
  { p: 167, t: 3, precio: 12300, hist: [13200, 13000, 12700] },
  { p: 167, t: 4, precio: 12300, hist: [11700, 11900, 12100] },
  { p: 167, t: 6, precio: 12000, hist: [13100, 13000, 12500] },
  // 168 Cables pasacorriente de 4 metros calibre 6
  { p: 168, t: 3, precio: 17400, hist: [18200, 18100, 17500] },
  { p: 168, t: 4, precio: 15900, hist: [14900, 15300, 15800] },
  { p: 168, t: 6, precio: 17100, hist: [17900, 17500, 17300] },
  // 169 Cables pasacorriente de 5 metros uso pesado
  { p: 169, t: 3, precio: 22600, hist: [21800, 22300, 22500] },
  { p: 169, t: 4, precio: 22500, hist: [25600, 22900, 22800] },
  { p: 169, t: 6, precio: 24600, hist: [27200, 25400, 25200] },
  // 170 Cables pasacorriente de 6 metros calibre 4 profesional
  { p: 170, t: 3, precio: 30700, hist: [32600, 31700, 31100] },
  { p: 170, t: 4, precio: 33300, hist: [34800, 34200, 33600] }
];

/* ---------------------------------------------------------------------
   TABLA: COMBOS  (ofertas exclusivas)
   tienda      -> id de la tienda que ofrece el combo
   productos   -> ids de PRODUCTOS cuyas fotos se muestran en el combo
   incluye     -> lista de lo que trae el combo
   precio      -> precio del combo
   porSeparado -> lo que costaría comprar todo por separado
   (el % de descuento NO se guarda: se calcula en app.js con
    (porSeparado - precio) / porSeparado, así nunca queda desactualizado)
   --------------------------------------------------------------------- */
const COMBOS = [
  { id: 1, nombre: "Combo Consola Slim + control extra", tienda: 1, emoji: "🎮", productos: [4],
    incluye: ["Consola de videojuegos Slim 1 TB", "Control inalámbrico adicional"],
    precio: 410000, porSeparado: 438000 },
  { id: 2, nombre: "Combo Cocina completa", tienda: 1, emoji: "🔥", productos: [26, 126],
    incluye: ["Refrigeradora Top Freezer 12 pies", "Cocina a gas 4 quemadores 20 pulgadas"],
    precio: 349900, porSeparado: 369100 },
  { id: 3, nombre: "Combo Taller en casa", tienda: 3, emoji: "🔧", productos: [8, 9],
    incluye: ["Taladro inalámbrico 20V con 2 baterías", "Caja de herramientas 120 piezas"],
    precio: 69900, porSeparado: 74400 },
  { id: 4, nombre: "Combo Hogar renovado", tienda: 4, emoji: "🛏️", productos: [6, 7],
    incluye: ["Juego de sábanas queen 400 hilos", "Set de ollas antiadherentes 10 piezas"],
    precio: 54900, porSeparado: 59000 },
  { id: 5, nombre: "Combo Auto listo", tienda: 3, emoji: "🔋", productos: [11, 166],
    incluye: ["Batería para auto 12V 60Ah", "Cables pasacorriente de 2 metros"],
    precio: 82500, porSeparado: 87000 }
];

/* ---------------------------------------------------------------------
   TABLA: SITUACIONES (tarjetas "Ver productos →" del inicio)
   categoria -> a qué categoría lleva el enlace al hacer clic
   --------------------------------------------------------------------- */
const SITUACIONES = [
  { id: "cocina", nombre: "Equipar la cocina", icono: "🍳", categoria: "linea-blanca" },
  { id: "entretenimiento", nombre: "Entretenimiento en casa", icono: "🎮", categoria: "electronicos" },
  { id: "cuarto", nombre: "Renovar el cuarto", icono: "🛏️", categoria: "hogar" },
  { id: "remodelar", nombre: "Remodelar la casa", icono: "🧰", categoria: "ferreteria" },
  { id: "carro", nombre: "Mantenimiento del carro", icono: "🚗", categoria: "automotriz" }
];
