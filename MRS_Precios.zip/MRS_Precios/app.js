/* =====================================================================
   app.js  -  Lógica de MRS Precios
   ---------------------------------------------------------------------
   Orden del archivo:
     1. Utilidades (formato de precios, textos seguros, guardado local)
     2. Consultas a los datos (precio más barato, descuentos, conteos)
     3. Estado (favoritos, comparar, filtros)
     4. Piezas de HTML (tarjetas, menú, botones)
     5. Pantallas (inicio, búsqueda, detalle, comparar, etc.)
     6. Navegación entre pantallas
     7. Eventos (clics, formularios, cookies)
     8. Arranque
   Usa las tablas de datos.js: TIENDAS, CATEGORIAS, PRODUCTOS, PRECIOS,
   COMBOS y SITUACIONES.
   ===================================================================== */
"use strict";

/* =====================================================================
   1. UTILIDADES
   ===================================================================== */
const $  = (selector, contexto = document) => contexto.querySelector(selector);
const $$ = (selector, contexto = document) => Array.from(contexto.querySelectorAll(selector));

// 353900 -> "₡353.900"
function colones(n) {
  return "₡" + String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

// Evita que un texto escrito por la persona se interprete como HTML
function esc(texto) {
  return String(texto).replace(/[&<>"']/g, (c) => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]
  ));
}

// Minúsculas y sin tildes, para que "audifonos" encuentre "Audífonos"
function normalizar(texto) {
  return String(texto).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function plural(n, singular, plur) { return n === 1 ? singular : plur; }

// Lectura y escritura en localStorage. El try/catch evita errores si el
// navegador bloquea el almacenamiento.
const Guardado = {
  leer(clave, porDefecto) {
    try {
      const valor = localStorage.getItem(clave);
      return valor ? JSON.parse(valor) : porDefecto;
    } catch (e) { return porDefecto; }
  },
  escribir(clave, valor) {
    try { localStorage.setItem(clave, JSON.stringify(valor)); } catch (e) { /* sin almacenamiento */ }
  }
};

let temporizadorAviso = null;
function aviso(mensaje) {
  const caja = $("#toast");
  caja.textContent = mensaje;
  caja.classList.add("visible");
  clearTimeout(temporizadorAviso);
  temporizadorAviso = setTimeout(() => caja.classList.remove("visible"), 2600);
}

/* =====================================================================
   2. CONSULTAS A LOS DATOS
   Aquí se "unen" las tablas usando las llaves p (producto) y t (tienda).
   ===================================================================== */
const tiendasPorId     = new Map(TIENDAS.map((t) => [t.id, t]));
const productosPorId   = new Map(PRODUCTOS.map((p) => [p.id, p]));
const categoriasPorId  = new Map(CATEGORIAS.map((c) => [c.id, c]));

// Filas de PRECIOS de un producto, de la más barata a la más cara.
// Si se pasa un conjunto de tiendas, solo se consideran esas.
function preciosDe(idProducto, tiendasPermitidas = null) {
  const usarFiltro = tiendasPermitidas && tiendasPermitidas.size > 0;
  return PRECIOS
    .filter((f) => f.p === idProducto && (!usarFiltro || tiendasPermitidas.has(f.t)))
    .sort((a, b) => a.precio - b.precio);
}

// La fila más barata: de aquí sale el "desde ₡ X en [tienda]"
function mejorFila(idProducto, tiendasPermitidas = null) {
  return preciosDe(idProducto, tiendasPermitidas)[0] || null;
}

// ¿El precio más bajo de hoy es el más bajo de los últimos 30 días?
function esMejorEn30Dias(idProducto) {
  const mejor = mejorFila(idProducto);
  if (!mejor) return false;
  const todos = PRECIOS
    .filter((f) => f.p === idProducto)
    .flatMap((f) => [...f.hist, f.precio]);
  return mejor.precio <= Math.min(...todos);
}

// % que bajó una fila respecto a hace 30 días (0 si no bajó)
function bajadaPct(fila) {
  const antes = fila.hist[0];
  return antes > fila.precio ? Math.round(((antes - fila.precio) / antes) * 100) : 0;
}

// El descuento de un combo se calcula, no se guarda
function descuentoCombo(combo) {
  return Math.round(((combo.porSeparado - combo.precio) / combo.porSeparado) * 100);
}

function cantidadTiendasDe(idProducto) {
  return new Set(PRECIOS.filter((f) => f.p === idProducto).map((f) => f.t)).size;
}
function cantidadProductosTienda(idTienda) {
  return new Set(PRECIOS.filter((f) => f.t === idTienda).map((f) => f.p)).size;
}
function cantidadProductosCategoria(idCategoria) {
  return PRODUCTOS.filter((p) => p.categoria === idCategoria).length;
}

// Palabras que la gente usa y que no están tal cual en el nombre
const SINONIMOS = {
  televisor: "tv", television: "tv", pantalla: "tv",
  refri: "refrigeradora", nevera: "refrigeradora",
  bocina: "parlante", cocineta: "cocina", freezer: "congelador",
  carro: "automotriz", auto: "automotriz", llantas: "llanta"
};

function coincideBusqueda(producto, texto) {
  const palabras = normalizar(texto).split(/\s+/).filter(Boolean);
  if (palabras.length === 0) return true;
  const categoria = categoriasPorId.get(producto.categoria).nombre;
  const contenido = normalizar(`${producto.nombre} ${producto.marca} ${categoria} ${producto.descripcion}`);
  // Deben aparecer TODAS las palabras (o su sinónimo)
  return palabras.every((pal) => contenido.includes(pal) || (SINONIMOS[pal] && contenido.includes(SINONIMOS[pal])));
}

/* =====================================================================
   3. ESTADO
   ===================================================================== */
let favoritos = Guardado.leer("mrs_favoritos", []);   // ids de productos
let comparar  = Guardado.leer("mrs_comparar", []);    // máximo 3 ids
let tiendaDelCombo = 0;                                // 0 = todas
let anclaPendiente = "";

const LIMITE_COMPARAR = 3;
const IDS_DESTACADOS = [3, 4, 1, 2, 5, 8, 136, 131];

// Filtros de la pantalla de búsqueda
const filtros = { q: "", cats: new Set(), tiendas: new Set(), precioMax: null, orden: "relevancia" };

function reiniciarFiltros() {
  filtros.q = "";
  filtros.cats = new Set();
  filtros.tiendas = new Set();
  filtros.precioMax = null;
  filtros.orden = "relevancia";
}

/* =====================================================================
   4. PIEZAS DE HTML
   ===================================================================== */
// Foto del producto: img/<imagen>.jpg (todas las fotos están en .jpg).
// Si la foto no carga, se muestra el emoji del producto.
function htmlImagen(producto, clase = "foto-producto") {
  if (!producto.imagen) return `<span aria-hidden="true">${producto.emoji}</span>`;
  return `<img class="${clase}" src="img/${producto.imagen}.jpg" alt="${esc(producto.nombre)}"
    loading="lazy" data-emoji="${producto.emoji}" onerror="imagenFallo(this)">`;
}

function imagenFallo(img) {
  const emoji = document.createElement("span");
  emoji.setAttribute("aria-hidden", "true");
  emoji.textContent = img.dataset.emoji;
  img.replaceWith(emoji);
}

// Los combos muestran las fotos de los productos que incluyen
function fotosCombo(combo) {
  const productos = (combo.productos || []).map((id) => productosPorId.get(id)).filter((p) => p && p.imagen);
  if (productos.length === 0) return `<span aria-hidden="true">${combo.emoji}</span>`;
  return `<div class="combo-fotos">${productos.map((p) => htmlImagen(p)).join("")}</div>`;
}

function botonesAccion(id) {
  const esFav = favoritos.includes(id);
  const esCmp = comparar.includes(id);
  return `
    <button class="btn-icono-chico ${esFav ? "activo" : ""}" data-accion="fav" data-id="${id}" aria-pressed="${esFav}">${esFav ? "♥ Guardado" : "♡ Guardar"}</button>
    <button class="btn-icono-chico ${esCmp ? "activo" : ""}" data-accion="cmp" data-id="${id}" aria-pressed="${esCmp}">${esCmp ? "✓ Comparando" : "⚖ Comparar"}</button>`;
}

// Tarjeta de producto: muestra el precio más barato y en qué tienda está
function tarjetaProducto(producto, tiendasPermitidas = null) {
  const mejor = mejorFila(producto.id, tiendasPermitidas);
  if (!mejor) return "";
  const tienda = tiendasPorId.get(mejor.t);
  const baja = bajadaPct(mejor);
  const nTiendas = cantidadTiendasDe(producto.id);
  const enlace = `#/producto/${producto.id}`;
  return `
    <article class="tarjeta-producto">
      <a class="tarjeta-producto__img" href="${enlace}" aria-label="Ver ${esc(producto.nombre)}">
        ${baja ? `<span class="insignia-descuento">-${baja}%</span>` : ""}
        ${htmlImagen(producto)}
      </a>
      <div class="tarjeta-producto__cuerpo">
        ${esMejorEn30Dias(producto.id) ? `<span class="etiqueta-mejor">Mejor precio en 30 días</span>` : ""}
        <a class="tarjeta-producto__nombre" href="${enlace}">${esc(producto.nombre)}</a>
        <span class="tarjeta-producto__marca">${esc(producto.marca)}</span>
        <span class="tarjeta-producto__desde">Desde</span>
        <span class="tarjeta-producto__precio">${colones(mejor.precio)}</span>
        <span class="tarjeta-producto__tienda">en ${esc(tienda.nombre)} (${nTiendas} ${plural(nTiendas, "tienda", "tiendas")})</span>
        <div class="tarjeta-producto__acciones">${botonesAccion(producto.id)}</div>
      </div>
    </article>`;
}

function tarjetaCombo(combo) {
  const tienda = tiendasPorId.get(combo.tienda);
  return `
    <article class="tarjeta-combo">
      <div class="tarjeta-combo__img">
        <span class="insignia-alianza">Combo exclusivo</span>
        <span class="insignia-descuento">-${descuentoCombo(combo)}%</span>
        ${fotosCombo(combo)}
      </div>
      <div class="tarjeta-combo__cuerpo">
        <h3 class="tarjeta-combo__nombre">${esc(combo.nombre)}</h3>
        <ul class="lista-incluye">${combo.incluye.map((i) => `<li>${esc(i)}</li>`).join("")}</ul>
        <div class="tarjeta-combo__precio">${colones(combo.precio)}</div>
        <div class="tarjeta-combo__separado">Por separado: ${colones(combo.porSeparado)}</div>
        <div class="tarjeta-combo__tienda">En <a href="#/tienda/${tienda.slug}">${esc(tienda.nombre)}</a></div>
      </div>
    </article>`;
}

function tarjetaTienda(tienda) {
  const n = cantidadProductosTienda(tienda.id);
  return `
    <a class="tarjeta-tienda" href="#/tienda/${tienda.slug}">
      <span class="logo-tienda" style="background:${tienda.color}" aria-hidden="true">${esc(tienda.nombre[0])}</span>
      <span class="tarjeta-tienda__nombre">${esc(tienda.nombre)}</span>
      <span class="tarjeta-tienda__cantidad">${n} ${plural(n, "producto", "productos")}</span>
    </a>`;
}

function mensajeVacio(titulo, detalle) {
  return `<div class="vacio"><strong>${titulo}</strong>${detalle}</div>`;
}

/* =====================================================================
   5. PANTALLAS
   ===================================================================== */

/* ---------- Partes que se dibujan una sola vez al abrir la página ---------- */
function pintarMenuCategorias() {
  $("#menu-categorias-grid").innerHTML = CATEGORIAS.map((c) => `
    <button class="cat-item" data-cat="${c.id}">
      <span class="cat-item__icono" aria-hidden="true">${c.icono}</span>
      <span class="cat-item__nombre">${c.nombre}</span>
      <span class="cat-item__cantidad">${cantidadProductosCategoria(c.id)}</span>
    </button>`).join("");
}

function pintarSituaciones() {
  $("#lista-situaciones").innerHTML = SITUACIONES.map((s) => `
    <button class="tarjeta-situacion" data-cat="${s.categoria}">
      <span class="tarjeta-situacion__icono" aria-hidden="true">${s.icono}</span>
      <span class="tarjeta-situacion__nombre">${s.nombre}</span>
      <span class="tarjeta-situacion__enlace">Ver productos →</span>
    </button>`).join("");
}

function pintarCombosInicio() {
  const idsTiendas = [...new Set(COMBOS.map((c) => c.tienda))];
  $("#filtro-tiendas-combos").innerHTML =
    `<button class="pildora ${tiendaDelCombo === 0 ? "activa" : ""}" data-combo-tienda="0">Todas</button>` +
    idsTiendas.map((id) => {
      const t = tiendasPorId.get(id);
      return `<button class="pildora ${tiendaDelCombo === id ? "activa" : ""}" data-combo-tienda="${id}">
        <span class="pildora__punto" style="background:${t.color}"></span>${esc(t.nombre)}</button>`;
    }).join("");
  const lista = COMBOS.filter((c) => tiendaDelCombo === 0 || c.tienda === tiendaDelCombo);
  $("#carrusel-combos").innerHTML = lista.map(tarjetaCombo).join("");
}

function pintarPartesFijas() {
  pintarMenuCategorias();
  pintarSituaciones();
  pintarCombosInicio();

  $("#grid-destacados").innerHTML = IDS_DESTACADOS
    .map((id) => tarjetaProducto(productosPorId.get(id))).join("");

  $("#grid-tiendas-inicio").innerHTML = TIENDAS.map(tarjetaTienda).join("");
  $("#grid-tiendas").innerHTML = TIENDAS.map(tarjetaTienda).join("");

  // Ofertas del día: combos + productos que más bajaron en 30 días
  $("#grid-combos-ofertas").innerHTML = COMBOS.map(tarjetaCombo).join("");
  const conBaja = PRODUCTOS
    .map((p) => ({ p, baja: bajadaPct(mejorFila(p.id)) }))
    .filter((x) => x.baja > 0)
    .sort((a, b) => b.baja - a.baja)
    .slice(0, 12);
  $("#grid-ofertas").innerHTML = conBaja.map((x) => tarjetaProducto(x.p)).join("");

  // Mejor precio en 30 días
  // Con muchos productos mostramos solo los 12 que más bajaron de precio
  const mejores = PRODUCTOS
    .filter((p) => esMejorEn30Dias(p.id))
    .map((p) => ({ p, baja: bajadaPct(mejorFila(p.id)) }))
    .sort((a, b) => b.baja - a.baja)
    .slice(0, 12)
    .map((x) => x.p);
  $("#grid-mejor-30").innerHTML = mejores.map((p) => tarjetaProducto(p)).join("");
  $("#vacio-mejor-30").classList.toggle("oculto", mejores.length > 0);

  // Fecha del pie de página: 2026-11-19 -> 19/11/2026
  const [anio, mes, dia] = FECHA_ACTUALIZACION.split("-");
  $("#fecha-actualizacion").textContent = `${dia}/${mes}/${anio}`;
}

/* ---------- Búsqueda, categorías y tienda ---------- */
function pintarFiltros() {
  $("#filtros-categorias").innerHTML = CATEGORIAS.map((c) => `
    <label class="opcion"><input type="checkbox" data-filtro="cat" value="${c.id}" ${filtros.cats.has(c.id) ? "checked" : ""}> ${c.nombre}</label>`).join("");
  $("#filtros-tiendas").innerHTML = TIENDAS.map((t) => `
    <label class="opcion"><input type="checkbox" data-filtro="tienda" value="${t.id}" ${filtros.tiendas.has(t.id) ? "checked" : ""}> ${esc(t.nombre)}</label>`).join("");
  $("#filtro-precio-max").value = filtros.precioMax === null ? "" : filtros.precioMax;
  $("#orden").value = filtros.orden;
}

function productosFiltrados() {
  let lista = PRODUCTOS.filter((p) =>
    coincideBusqueda(p, filtros.q) &&
    (filtros.cats.size === 0 || filtros.cats.has(p.categoria))
  );

  // Precio de referencia = el más barato entre las tiendas elegidas
  lista = lista.filter((p) => {
    const mejor = mejorFila(p.id, filtros.tiendas);
    return mejor && (filtros.precioMax === null || mejor.precio <= filtros.precioMax);
  });

  const precio = (p) => mejorFila(p.id, filtros.tiendas).precio;
  const baja = (p) => bajadaPct(mejorFila(p.id, filtros.tiendas));
  switch (filtros.orden) {
    case "menor":     lista.sort((a, b) => precio(a) - precio(b)); break;
    case "mayor":     lista.sort((a, b) => precio(b) - precio(a)); break;
    case "nombre":    lista.sort((a, b) => a.nombre.localeCompare(b.nombre, "es")); break;
    case "descuento": lista.sort((a, b) => baja(b) - baja(a)); break;
    default: break; // relevancia: el orden original de la tabla
  }
  return lista;
}

function actualizarTituloBusqueda() {
  let titulo = "Todos los productos";
  let subtitulo = "";
  if (filtros.q) {
    titulo = `Resultados para “${filtros.q}”`;
  } else if (filtros.cats.size === 1) {
    titulo = categoriasPorId.get([...filtros.cats][0]).nombre;
  } else if (filtros.tiendas.size === 1) {
    const t = tiendasPorId.get([...filtros.tiendas][0]);
    titulo = `Productos en ${t.nombre}`;
    subtitulo = t.tipo;
  }
  $("#titulo-busqueda").textContent = titulo;
  $("#subtitulo-busqueda").textContent = subtitulo;
  document.title = `${titulo} — MRS Precios`;
}

function pintarResultados() {
  const lista = productosFiltrados();
  $("#grid-resultados").innerHTML = lista.map((p) => tarjetaProducto(p, filtros.tiendas)).join("");
  $("#contador-resultados").textContent = `${lista.length} ${plural(lista.length, "producto", "productos")}`;
  $("#vacio-busqueda").classList.toggle("oculto", lista.length > 0);
  actualizarTituloBusqueda();
}

/* ---------- Detalle de producto ---------- */
function textoCambio(fila) {
  const antes = fila.hist[0];
  if (fila.precio < antes) {
    return `<span class="tendencia-baja">↓ ${Math.round(((antes - fila.precio) / antes) * 100)}% en 30 días</span>`;
  }
  if (fila.precio > antes) {
    return `<span class="tendencia-sube">↑ ${Math.round(((fila.precio - antes) / antes) * 100)}% en 30 días</span>`;
  }
  return `<span class="dif-precio">Sin cambio</span>`;
}

// Gráfico de líneas en SVG: una línea por tienda, 4 puntos en el tiempo
function graficoHistorial(filas) {
  const ANCHO = 720, ALTO = 320, izq = 92, der = 24, arriba = 20, abajo = 44;
  const etiquetas = ["Hace 30 días", "Hace 20 días", "Hace 10 días", "Hoy"];
  const series = filas.map((f) => ({ tienda: tiendasPorId.get(f.t), valores: [...f.hist, f.precio] }));

  const todos = series.flatMap((s) => s.valores);
  let minimo = Math.min(...todos);
  let maximo = Math.max(...todos);
  if (minimo === maximo) { minimo -= 1000; maximo += 1000; }
  const holgura = (maximo - minimo) * 0.1;
  minimo -= holgura;
  maximo += holgura;

  const x = (i) => izq + i * ((ANCHO - izq - der) / 3);
  const y = (v) => arriba + ((maximo - v) / (maximo - minimo)) * (ALTO - arriba - abajo);

  let svg = `<svg viewBox="0 0 ${ANCHO} ${ALTO}" role="img" aria-label="Historial de precios de los últimos 30 días por tienda">`;
  for (let i = 0; i <= 4; i++) {                      // líneas guía horizontales
    const valor = minimo + ((maximo - minimo) * i) / 4;
    const yy = y(valor);
    svg += `<line class="grafico__eje" x1="${izq}" x2="${ANCHO - der}" y1="${yy}" y2="${yy}"/>`;
    svg += `<text class="grafico__texto" x="${izq - 10}" y="${yy + 4}" text-anchor="end">${colones(Math.round(valor / 100) * 100)}</text>`;
  }
  etiquetas.forEach((e, i) => {
    svg += `<text class="grafico__texto" x="${x(i)}" y="${ALTO - 14}" text-anchor="middle">${e}</text>`;
  });
  series.forEach((s) => {
    const puntos = s.valores.map((v, i) => `${x(i)},${y(v)}`).join(" ");
    svg += `<polyline class="grafico__linea" stroke="${s.tienda.color}" points="${puntos}"/>`;
    s.valores.forEach((v, i) => {
      svg += `<circle class="grafico__punto" cx="${x(i)}" cy="${y(v)}" r="5" fill="${s.tienda.color}"><title>${esc(s.tienda.nombre)}: ${colones(v)}</title></circle>`;
    });
  });
  svg += `</svg>`;

  const leyenda = series.map((s) => `
    <span class="leyenda__item"><span class="leyenda__color" style="background:${s.tienda.color}"></span>${esc(s.tienda.nombre)}</span>`).join("");
  return `<div class="grafico">${svg}</div><div class="leyenda">${leyenda}</div>`;
}

function pintarDetalle(id) {
  const contenedor = $("#detalle-producto");
  const producto = productosPorId.get(id);
  if (!producto) {
    contenedor.innerHTML = mensajeVacio("No encontramos ese producto", `<a href="#/buscar">Ver todos los productos</a>`);
    document.title = "Producto no encontrado — MRS Precios";
    return;
  }

  const categoria = categoriasPorId.get(producto.categoria);
  const filas = preciosDe(id);
  const mejor = filas[0];
  const tiendaMejor = tiendasPorId.get(mejor.t);
  const baja = bajadaPct(mejor);

  const filasTabla = filas.map((f, i) => {
    const t = tiendasPorId.get(f.t);
    const diferencia = f.precio - mejor.precio;
    return `
      <tr class="${i === 0 ? "fila-mejor" : ""}">
        <td>
          <div class="celda-tienda">
            <span class="logo-tienda" style="background:${t.color}" aria-hidden="true">${esc(t.nombre[0])}</span>
            <a href="#/tienda/${t.slug}">${esc(t.nombre)}</a>
            ${i === 0 ? `<span class="etiqueta-mejor">Mejor precio</span>` : ""}
          </div>
        </td>
        <td class="celda-precio">${colones(f.precio)}</td>
        <td class="dif-precio">${i === 0 ? "—" : `+${colones(diferencia)} más caro`}</td>
        <td>${textoCambio(f)}</td>
      </tr>`;
  }).join("");

  const parecidos = PRODUCTOS
    .filter((p) => p.categoria === producto.categoria && p.id !== producto.id)
    .slice(0, 4);

  contenedor.innerHTML = `
    <nav class="migas" aria-label="Ruta">
      <a href="#/inicio">Inicio</a> / <a href="#/categoria/${categoria.id}">${categoria.nombre}</a> / ${esc(producto.nombre)}
    </nav>

    <div class="detalle">
      <div class="detalle__img">${htmlImagen(producto)}</div>
      <div>
        <div class="detalle__marca">${esc(producto.marca)} · ${categoria.nombre}</div>
        <h1 class="detalle__titulo">${esc(producto.nombre)}</h1>
        <p class="detalle__desc">${esc(producto.descripcion)}</p>

        <div class="detalle__resumen">
          <div>
            <div class="detalle__tienda">Mejor precio hoy</div>
            <div class="detalle__precio">${colones(mejor.precio)}</div>
          </div>
          <div class="detalle__tienda">en <strong>${esc(tiendaMejor.nombre)}</strong><br>Comparado en ${filas.length} ${plural(filas.length, "tienda", "tiendas")}</div>
          ${esMejorEn30Dias(id) ? `<span class="etiqueta-mejor">Mejor precio en 30 días</span>` : ""}
          ${baja ? `<span class="etiqueta-mejor">Bajó ${baja}% en 30 días</span>` : ""}
        </div>

        <div class="detalle__acciones">
          ${botonesAccion(id)}
          <a class="btn btn-borde btn-chico" href="#/tienda/${tiendaMejor.slug}">Ver ${esc(tiendaMejor.nombre)}</a>
        </div>
      </div>
    </div>

    <div class="caja">
      <h2>Precio en cada tienda</h2>
      <div class="tabla-envoltorio">
        <table class="tabla-precios">
          <thead><tr><th>Tienda</th><th>Precio</th><th>Diferencia</th><th>Cambio</th></tr></thead>
          <tbody>${filasTabla}</tbody>
        </table>
      </div>
    </div>

    <div class="caja">
      <h2>Historial de precios (30 días)</h2>
      ${graficoHistorial(filas)}
    </div>

    ${parecidos.length ? `
      <div class="seccion">
        <h2 class="seccion__titulo">Más en ${categoria.nombre}</h2>
        <div class="grid-productos" style="margin-top: 20px">${parecidos.map((p) => tarjetaProducto(p)).join("")}</div>
      </div>` : ""}`;

  document.title = `${producto.nombre} — MRS Precios`;
}

/* ---------- Favoritos y comparar ---------- */
function pintarFavoritos() {
  const lista = favoritos.map((id) => productosPorId.get(id)).filter(Boolean);
  $("#grid-favoritos").innerHTML = lista.map((p) => tarjetaProducto(p)).join("");
  $("#vacio-favoritos").classList.toggle("oculto", lista.length > 0);
}

function pintarComparar() {
  const contenedor = $("#contenedor-comparar");
  const productos = comparar.map((id) => productosPorId.get(id)).filter(Boolean);

  if (productos.length === 0) {
    contenedor.classList.add("oculto");
    $("#vacio-comparar").classList.remove("oculto");
    return;
  }
  contenedor.classList.remove("oculto");
  $("#vacio-comparar").classList.add("oculto");

  const encabezados = productos.map((p) => `
    <th class="col-producto">
      ${htmlImagen(p, "mini-foto")}
      <a href="#/producto/${p.id}">${esc(p.nombre)}</a><br>
      <button class="btn-icono-chico" style="margin-top:8px" data-accion="quitar-cmp" data-id="${p.id}">Quitar</button>
    </th>`).join("");

  // Solo mostramos las tiendas que tienen precio de al menos uno de los productos
  const tiendasUsadas = TIENDAS.filter((t) => productos.some((p) => PRECIOS.some((f) => f.p === p.id && f.t === t.id)));

  const filas = tiendasUsadas.map((t) => {
    const celdas = productos.map((p) => {
      const fila = PRECIOS.find((f) => f.p === p.id && f.t === t.id);
      if (!fila) return `<td>—</td>`;
      const esMejor = mejorFila(p.id).t === t.id;
      return `<td class="${esMejor ? "mejor" : ""}">${colones(fila.precio)}</td>`;
    }).join("");
    return `<tr><td><strong>${esc(t.nombre)}</strong></td>${celdas}</tr>`;
  }).join("");

  const resumen = productos.map((p) => {
    const m = mejorFila(p.id);
    return `<td><strong>${esc(tiendasPorId.get(m.t).nombre)}</strong></td>`;
  }).join("");

  contenedor.innerHTML = `
    <table class="tabla-comparar">
      <thead><tr><th>Tienda</th>${encabezados}</tr></thead>
      <tbody>
        ${filas}
        <tr><td><strong>Tienda más barata</strong></td>${resumen}</tr>
      </tbody>
    </table>
    <p style="margin: 18px 0 0"><button class="btn btn-borde btn-chico" data-accion="vaciar-cmp">Vaciar comparación</button></p>`;
}

function actualizarContadores() {
  const fav = $("#contador-favoritos");
  const cmp = $("#contador-comparar");
  fav.textContent = favoritos.length;
  fav.dataset.valor = favoritos.length;
  cmp.textContent = comparar.length;
  cmp.dataset.valor = comparar.length;
}

// Cambia el aspecto de TODOS los botones de guardar/comparar de la página
function actualizarBotones() {
  $$('[data-accion="fav"]').forEach((b) => {
    const activo = favoritos.includes(Number(b.dataset.id));
    b.classList.toggle("activo", activo);
    b.setAttribute("aria-pressed", activo);
    b.textContent = activo ? "♥ Guardado" : "♡ Guardar";
  });
  $$('[data-accion="cmp"]').forEach((b) => {
    const activo = comparar.includes(Number(b.dataset.id));
    b.classList.toggle("activo", activo);
    b.setAttribute("aria-pressed", activo);
    b.textContent = activo ? "✓ Comparando" : "⚖ Comparar";
  });
}

function despuesDeCambiarListas() {
  Guardado.escribir("mrs_favoritos", favoritos);
  Guardado.escribir("mrs_comparar", comparar);
  actualizarContadores();
  actualizarBotones();
  const actual = leerRuta().nombre;
  if (actual === "favoritos") pintarFavoritos();
  if (actual === "comparar") pintarComparar();
}

function alternarFavorito(id) {
  if (favoritos.includes(id)) {
    favoritos = favoritos.filter((x) => x !== id);
    aviso("Quitado de favoritos");
  } else {
    favoritos.push(id);
    aviso("Guardado en favoritos");
  }
  despuesDeCambiarListas();
}

function alternarComparar(id) {
  if (comparar.includes(id)) {
    comparar = comparar.filter((x) => x !== id);
    aviso("Quitado de la comparación");
  } else {
    if (comparar.length >= LIMITE_COMPARAR) {
      aviso(`Puedes comparar hasta ${LIMITE_COMPARAR} productos a la vez`);
      return;
    }
    comparar.push(id);
    aviso("Agregado para comparar");
  }
  despuesDeCambiarListas();
}

/* =====================================================================
   6. NAVEGACIÓN ENTRE PANTALLAS
   La dirección (#/producto/3, #/tienda/casa-tica, #/buscar?q=tv) decide
   qué pantalla se muestra. Por eso el botón "atrás" funciona.
   ===================================================================== */
const PANTALLAS = ["inicio", "busqueda", "producto", "tiendas", "ofertas", "mejor-precio",
                   "favoritos", "comparar", "pedir", "como-funciona"];

const TITULOS = {
  inicio: "Comparador de precios en Costa Rica", tiendas: "Tiendas que comparamos",
  ofertas: "Ofertas del día", "mejor-precio": "Mejor precio en 30 días",
  favoritos: "Mis favoritos", comparar: "Comparar precios", pedir: "Pedí precio",
  "como-funciona": "Cómo funciona"
};

function leerRuta() {
  const texto = location.hash.replace(/^#\/?/, "");
  const [ruta, consulta = ""] = texto.split("?");
  const partes = ruta.split("/").filter(Boolean);
  let argumento = partes[1] || "";
  try { argumento = decodeURIComponent(argumento); } catch (e) { /* se deja tal cual */ }
  return { nombre: partes[0] || "inicio", arg: argumento, params: new URLSearchParams(consulta) };
}

function navegar(ruta, ancla = "") {
  anclaPendiente = ancla;
  const destino = "#/" + ruta;
  if (location.hash === destino) enrutar(); else location.hash = destino;
}

function abrirMenu() {
  $("#menu-categorias").classList.add("abierto");
  $("#fondo-oscuro").classList.add("visible");
  $("#btn-categorias").classList.add("activo");
  $("#btn-categorias").setAttribute("aria-expanded", "true");
}
function cerrarMenu() {
  $("#menu-categorias").classList.remove("abierto");
  $("#fondo-oscuro").classList.remove("visible");
  $("#btn-categorias").classList.remove("activo");
  $("#btn-categorias").setAttribute("aria-expanded", "false");
}

function mostrarPantalla(nombre) {
  $$(".pantalla").forEach((p) => p.classList.remove("activa"));
  $(`#pantalla-${nombre}`).classList.add("activa");

  // Resalta en celeste la opción de la barra azul que corresponde
  $$(".nav-item[data-ir]").forEach((b) => b.classList.toggle("activo", b.dataset.ir === nombre));
}

function enrutar() {
  // Enlaces como "Saltar al contenido" (#contenido) no son rutas
  if (location.hash && !location.hash.startsWith("#/")) return;

  const ruta = leerRuta();
  let pantalla = PANTALLAS.includes(ruta.nombre) ? ruta.nombre : "inicio";

  switch (ruta.nombre) {
    case "buscar":
      reiniciarFiltros();
      filtros.q = (ruta.params.get("q") || "").trim();
      pintarFiltros();
      pintarResultados();
      pantalla = "busqueda";
      break;

    case "categoria":
      if (categoriasPorId.has(ruta.arg)) {
        reiniciarFiltros();
        filtros.cats.add(ruta.arg);
        pintarFiltros();
        pintarResultados();
        pantalla = "busqueda";
      } else { pantalla = "inicio"; }
      break;

    case "tienda": {
      const tienda = TIENDAS.find((t) => t.slug === ruta.arg);
      if (tienda) {
        reiniciarFiltros();
        filtros.tiendas.add(tienda.id);
        pintarFiltros();
        pintarResultados();
        pantalla = "busqueda";
      } else { pantalla = "inicio"; }
      break;
    }

    case "producto":
      pintarDetalle(Number(ruta.arg));
      pantalla = "producto";
      break;

    case "favoritos": pintarFavoritos(); break;
    case "comparar":  pintarComparar(); break;
    default: break;
  }

  mostrarPantalla(pantalla);
  cerrarMenu();

  if (TITULOS[pantalla]) document.title = `${TITULOS[pantalla]} — MRS Precios`;
  if (pantalla === "busqueda") $("#input-buscar").value = filtros.q;

  if (anclaPendiente && $(`#${anclaPendiente}`)) {
    $(`#${anclaPendiente}`).scrollIntoView();
  } else {
    window.scrollTo(0, 0);
  }
  anclaPendiente = "";
}

/* =====================================================================
   7. EVENTOS
   Se usa "delegación": un solo oyente en todo el documento que revisa
   qué se tocó. Así funciona también con las tarjetas dibujadas después.
   ===================================================================== */
document.addEventListener("click", (e) => {
  const elemento = e.target.closest("[data-ir], [data-accion], [data-cat], [data-combo-tienda], #btn-categorias, #fondo-oscuro, #btn-cuenta");
  if (!elemento) return;

  if (elemento.id === "btn-categorias") {
    if ($("#menu-categorias").classList.contains("abierto")) cerrarMenu(); else abrirMenu();
    return;
  }
  if (elemento.id === "fondo-oscuro") { cerrarMenu(); return; }
  if (elemento.id === "btn-cuenta") { aviso("El inicio de sesión no está disponible en esta versión"); return; }

  if (elemento.dataset.ir) { navegar(elemento.dataset.ir, elemento.dataset.ancla || ""); return; }
  if (elemento.dataset.cat) { navegar(`categoria/${elemento.dataset.cat}`); return; }

  if (elemento.dataset.comboTienda !== undefined) {
    tiendaDelCombo = Number(elemento.dataset.comboTienda);
    pintarCombosInicio();
    return;
  }

  const id = Number(elemento.dataset.id);
  switch (elemento.dataset.accion) {
    case "fav":        alternarFavorito(id); break;
    case "cmp":        alternarComparar(id); break;
    case "quitar-cmp": comparar = comparar.filter((x) => x !== id); despuesDeCambiarListas(); break;
    case "vaciar-cmp": comparar = []; despuesDeCambiarListas(); break;
    default: break;
  }
});

// Buscador del encabezado
$("#form-buscador").addEventListener("submit", (e) => {
  e.preventDefault();
  const texto = $("#input-buscar").value.trim();
  navegar(texto ? `buscar?q=${encodeURIComponent(texto)}` : "buscar");
});

// Filtros de la pantalla de búsqueda
function cambiarConjunto(conjunto, valor, marcado) {
  if (marcado) conjunto.add(valor); else conjunto.delete(valor);
}

document.addEventListener("change", (e) => {
  const campo = e.target;
  if (campo.matches('[data-filtro="cat"]'))         cambiarConjunto(filtros.cats, campo.value, campo.checked);
  else if (campo.matches('[data-filtro="tienda"]')) cambiarConjunto(filtros.tiendas, Number(campo.value), campo.checked);
  else if (campo.id === "orden")                    filtros.orden = campo.value;
  else return;
  pintarResultados();
});

$("#filtro-precio-max").addEventListener("input", (e) => {
  const valor = Number(e.target.value);
  filtros.precioMax = e.target.value !== "" && valor >= 0 ? valor : null;
  pintarResultados();
});

$("#btn-limpiar-filtros").addEventListener("click", () => navegar("buscar"));

// Formulario "Pedí precio"
$("#form-pedir").addEventListener("submit", (e) => {
  e.preventDefault();
  const producto = $("#pedir-producto").value.trim();
  const correo = $("#pedir-correo").value.trim();
  const detalle = $("#pedir-detalle").value.trim();
  const error = $("#error-pedir");
  const exito = $("#mensaje-pedir");
  error.classList.add("oculto");
  exito.classList.add("oculto");

  if (!producto) {
    error.textContent = "Escribe qué producto buscas.";
    error.classList.remove("oculto");
    $("#pedir-producto").focus();
    return;
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)) {
    error.textContent = "Escribe un correo válido, por ejemplo nombre@correo.com.";
    error.classList.remove("oculto");
    $("#pedir-correo").focus();
    return;
  }

  const solicitudes = Guardado.leer("mrs_solicitudes", []);
  solicitudes.push({ producto, correo, detalle, fecha: new Date().toISOString() });
  Guardado.escribir("mrs_solicitudes", solicitudes);

  exito.textContent = `Recibimos tu solicitud de “${producto}”. Te avisaremos en ${correo}.`;
  exito.classList.remove("oculto");
  e.target.reset();
});

// Aviso de cookies
function iniciarCookies() {
  const caja = $("#aviso-cookies");
  if (Guardado.leer("mrs_cookies", null)) { caja.classList.add("oculto"); return; }
  const responder = (eleccion) => () => {
    Guardado.escribir("mrs_cookies", eleccion);
    caja.classList.add("oculto");
  };
  $("#cookies-aceptar").addEventListener("click", responder("todo"));
  $("#cookies-necesario").addEventListener("click", responder("necesario"));
}

// Escape cierra el menú de categorías
document.addEventListener("keydown", (e) => { if (e.key === "Escape") cerrarMenu(); });

/* =====================================================================
   8. ARRANQUE
   ===================================================================== */
window.addEventListener("hashchange", enrutar);

pintarPartesFijas();
actualizarContadores();
iniciarCookies();
enrutar();
